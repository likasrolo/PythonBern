import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertPassportingAnalysisSchema, 
  insertNewsletterProcessSchema,
  insertClientSectionSchema,
  insertNewsletterTitleSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Save passporting analysis
  app.post('/api/passporting', async (req, res) => {
    try {
      const analysisData = insertPassportingAnalysisSchema.parse(req.body);
      const analysis = await storage.createPassportingAnalysis(analysisData);
      res.json(analysis);
    } catch (error) {
      console.error('Error saving passporting analysis:', error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : 'Erreur lors de la sauvegarde' 
      });
    }
  });

  // Get passporting analysis by id
  app.get('/api/passporting/:id', async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const analysis = await storage.getPassportingAnalysis(id);
      
      if (!analysis) {
        return res.status(404).json({ message: 'Analyse non trouvée' });
      }
      
      res.json(analysis);
    } catch (error) {
      console.error('Error fetching passporting analysis:', error);
      res.status(500).json({ 
        message: 'Erreur lors de la récupération de l\'analyse' 
      });
    }
  });

  // Get all passporting analyses
  app.get('/api/passporting', async (req, res) => {
    try {
      const analyses = await storage.getAllPassportingAnalyses();
      res.json(analyses);
    } catch (error) {
      console.error('Error fetching passporting analyses:', error);
      res.status(500).json({ 
        message: 'Erreur lors de la récupération des analyses' 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
