import { 
  users, 
  newsletterProcesses, 
  clientSections, 
  newsletterTitles,
  type User, 
  type InsertUser,
  type NewsletterProcess,
  type InsertNewsletterProcess,
  type ClientSection,
  type InsertClientSection,
  type NewsletterTitle,
  type InsertNewsletterTitle
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Newsletter methods
  createNewsletterProcess(process: InsertNewsletterProcess): Promise<NewsletterProcess>;
  getNewsletterProcess(id: number): Promise<NewsletterProcess | undefined>;
  listNewsletterProcesses(): Promise<NewsletterProcess[]>;
  updateNewsletterProcess(id: number, updates: Partial<NewsletterProcess>): Promise<NewsletterProcess | undefined>;
  
  createClientSection(section: InsertClientSection): Promise<ClientSection>;
  getClientSectionsByProcess(processId: number): Promise<ClientSection[]>;
  updateClientSection(id: number, updates: Partial<ClientSection>): Promise<ClientSection | undefined>;
  
  createNewsletterTitle(title: InsertNewsletterTitle): Promise<NewsletterTitle>;
  getNewsletterTitlesByProcess(processId: number): Promise<NewsletterTitle[]>;
  updateNewsletterTitle(id: number, updates: Partial<NewsletterTitle>): Promise<NewsletterTitle | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private newsletterProcesses: Map<number, NewsletterProcess>;
  private clientSections: Map<number, ClientSection>;
  private newsletterTitles: Map<number, NewsletterTitle>;
  currentId: number;

  constructor() {
    this.users = new Map();
    this.newsletterProcesses = new Map();
    this.clientSections = new Map();
    this.newsletterTitles = new Map();
    this.currentId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Newsletter Process methods
  async createNewsletterProcess(insertProcess: InsertNewsletterProcess): Promise<NewsletterProcess> {
    const id = this.currentId++;
    const now = new Date();
    const process: NewsletterProcess = { 
      ...insertProcess, 
      id, 
      status: insertProcess.status || "created",
      htmlContent: insertProcess.htmlContent || null,
      excelContent: insertProcess.excelContent || null,
      conseillerName: insertProcess.conseillerName || null,
      createdAt: now,
      updatedAt: now
    };
    this.newsletterProcesses.set(id, process);
    return process;
  }

  async getNewsletterProcess(id: number): Promise<NewsletterProcess | undefined> {
    return this.newsletterProcesses.get(id);
  }

  async listNewsletterProcesses(): Promise<NewsletterProcess[]> {
    return Array.from(this.newsletterProcesses.values());
  }

  async updateNewsletterProcess(id: number, updates: Partial<NewsletterProcess>): Promise<NewsletterProcess | undefined> {
    const existing = this.newsletterProcesses.get(id);
    if (!existing) return undefined;
    
    const updated: NewsletterProcess = { 
      ...existing, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.newsletterProcesses.set(id, updated);
    return updated;
  }

  // Client Section methods
  async createClientSection(insertSection: InsertClientSection): Promise<ClientSection> {
    const id = this.currentId++;
    const section: ClientSection = { 
      ...insertSection, 
      id,
      sectionPrompt: insertSection.sectionPrompt || null,
      aiResponse: insertSection.aiResponse || null
    };
    this.clientSections.set(id, section);
    return section;
  }

  async getClientSectionsByProcess(processId: number): Promise<ClientSection[]> {
    return Array.from(this.clientSections.values()).filter(
      section => section.processId === processId
    );
  }

  async updateClientSection(id: number, updates: Partial<ClientSection>): Promise<ClientSection | undefined> {
    const existing = this.clientSections.get(id);
    if (!existing) return undefined;
    
    const updated: ClientSection = { ...existing, ...updates };
    this.clientSections.set(id, updated);
    return updated;
  }

  // Newsletter Title methods
  async createNewsletterTitle(insertTitle: InsertNewsletterTitle): Promise<NewsletterTitle> {
    const id = this.currentId++;
    const title: NewsletterTitle = { 
      ...insertTitle, 
      id,
      clientNumbers: insertTitle.clientNumbers || null,
      comments: insertTitle.comments || null
    };
    this.newsletterTitles.set(id, title);
    return title;
  }

  async getNewsletterTitlesByProcess(processId: number): Promise<NewsletterTitle[]> {
    return Array.from(this.newsletterTitles.values()).filter(
      title => title.processId === processId
    );
  }

  async updateNewsletterTitle(id: number, updates: Partial<NewsletterTitle>): Promise<NewsletterTitle | undefined> {
    const existing = this.newsletterTitles.get(id);
    if (!existing) return undefined;
    
    const updated: NewsletterTitle = { ...existing, ...updates };
    this.newsletterTitles.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();
