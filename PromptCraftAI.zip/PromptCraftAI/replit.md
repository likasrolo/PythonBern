# Passporting Monaco

## Overview

This is a banking document analysis application built for Monaco's financial services sector. The application helps banks identify and analyze reusable documents for client onboarding through a "passporting" process, allowing clients to transfer documentation between different banking services (Private Banking to Retail Banking or vice versa).

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui components
- **Routing**: Wouter for client-side routing
- **State Management**: React state with TanStack Query for server state
- **Build Tool**: Vite with custom development server integration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **Database ORM**: Drizzle ORM
- **Database**: PostgreSQL (configured via Neon Database)
- **API Pattern**: RESTful API with JSON responses

### Development Environment
- **Bundler**: Vite for frontend, esbuild for backend production builds
- **TypeScript**: Strict mode enabled across the entire codebase
- **Dev Server**: Custom Vite integration with Express middleware
- **Hot Reload**: Enabled for both frontend and backend development

## Key Components

### Document Processing System
- **File Upload**: Supports CSV and Excel file processing
- **Content Extraction**: Reads and parses uploaded documents for analysis
- **Matrix Matching**: Compares client documents against predefined requirement matrices

### AI Integration Layer
- **Prompt Generation**: Automatically generates structured prompts based on client data and requirements
- **Results Processing**: Handles AI analysis results with table extraction capabilities
- **Export Functionality**: CSV export for analysis results

### Client Management
- **Person Types**: Supports both "Personne Physique" (Individual) and "Personne Morale" (Corporate)
- **Direction Toggle**: Bidirectional passporting (GP ↔ BDD)
- **Compliance Tracking**: PEP/SPO status and regulatory requirements

### Document Matrices
- **GP to BDD Matrix**: Requirements for Private Banking to Retail Banking transfer
- **BDD to GP Matrix**: Requirements for Retail Banking to Private Banking transfer
- **Type-Specific Rules**: Different requirements for individuals vs. corporations

## Data Flow

1. **Client Information Entry**: User inputs client type, LAB, country, PEP status, and specific needs
2. **Direction Selection**: User chooses passporting direction (GP→BDD or BDD→GP)
3. **Document Upload**: Client documents are uploaded and processed
4. **Prompt Generation**: System generates AI-ready prompt combining client data and relevant matrix
5. **AI Analysis**: External AI processes the prompt (integration point for future AI services)
6. **Results Processing**: Analysis results are parsed and table data is extracted
7. **Export**: Results can be exported as CSV for further use

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: PostgreSQL database connection
- **drizzle-orm**: Database ORM and query builder
- **@tanstack/react-query**: Server state management
- **@radix-ui/***: Accessible UI component primitives
- **wouter**: Lightweight React router

### Development Dependencies
- **vite**: Frontend build tool and dev server
- **tsx**: TypeScript execution for Node.js
- **tailwindcss**: Utility-first CSS framework
- **@replit/vite-plugin-***: Replit-specific development tools

### File Processing
- **csv-parser**: CSV file parsing capabilities
- **date-fns**: Date manipulation utilities

## Deployment Strategy

### Development
- Uses Vite's development server with Express middleware integration
- Hot module replacement for frontend changes
- Automatic TypeScript compilation and reloading for backend

### Production Build
- Frontend: Vite builds static assets to `dist/public`
- Backend: esbuild bundles server code to `dist/index.js`
- Database: Drizzle migrations applied via `db:push` command

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **NODE_ENV**: Environment mode (development/production)
- **REPL_ID**: Replit-specific environment identifier

### Hosting Requirements
- Node.js runtime with ES module support
- PostgreSQL database access
- Static file serving capability for frontend assets

## User Preferences

Preferred communication style: Simple, everyday language.

## Changelog

Changelog:
- July 03, 2025. Initial setup