// Application State
let appState = {
    currentStep: 1,
    direction: '1-to-2', // '1-to-2' or '2-to-1'
    importedFile: null,
    clientData: null,
        clientData: {
        type: '',
        lab: '',
        country: '',
        pep: '',
        besoins: ''
    },
    promptResults: {},
    matrices: null
};

// Matrix Content
const matrices = {
    matrix1_physique: `   
Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document

Personne Physique - Identification;Tous les clients;Identification Personne Physique;001-Identification Personne Physique 2020 |
Personne Physique - Documents complémentaires;Tous les clients;Convention d’entrée en relation Personne Physique;002-Convention d'Entrée en Relation PP 2020 |
Personne Physique - Fiscalité;Tous les clients;Auto-certification de résidence fiscale;029-Déclaration de résidence fiscale,202-CRS SELF CERTIFICATION |
Personne Physique - Fiscalité;Tous les clients;Questionnaire MIFID;598-Questionnaire MIFID |
Personne Physique - Fiscalité;Tous les clients;FATCA, W8 BEN;061-QI W9,063-Convention double imposition acceptée, 078-Convention double imposition refusée |
Personne Physique - Identifiaction;Tous les clients;Pièce d’identité en cours de validité du titulaire;020-Pièce identité du ou des mandataires, 034-Pièce identité actionnaires |
Personne Physique - ;Tous les clients;Lettre de référence bancaire;999-KYC |
Personne Physique - Justificatif de domicile;Tous les clients;Justificatif de domicile récent (< 6 mois);062-Attestation certificat |
Personne Physique - Revenus et patrimoine;Tous les Clients;Justificatif d’origine de la fortune;999-KYC, 815-Origine de la fortune |
Personne Physique - Revenus et patrimoine;Tous les clients;Justificatif de revenus;999-KYC, 816-Revenus |
Personne Physique - Revenus et patrimoine;Tous les clients;Audit Patrimonial ou Déclaration de Patrimoine;198-Audit patrimonial, 817-Patrimoine |
Personne Physique - Fiscalité;Ressortissants UE se déclarant non-résidents fiscaux ou ressortissants français se déclarant non-résidents fiscaux français ou Si le pays de résidence fiscale est différent du pays de résidence habituelle;Certificat de résidence fiscale;029-Déclaration de résidence fiscale, 129-Déclaration de résidence fiscale, 202-CRS SELF CERTIFICATION |
Personne Physique - Imposition;Hors Résident Fiscal Monégasque;Attestation Tax Compliance Framework ou Déclaration Fiscale;999-KYC 102-Justificatif d'exonération DEFE, 405-Justificatif complémentaire de conformité fiscale |
Personne Physique - Activité;Tous les clients;Parcours ou résumé de carrière(CV);999-KYC |
Personne Physique - Documents complémentaires;Tous les clients;Autorisation d’échange d’informations B.P.I;331-Autorisation d'échange d'information BPI |
Personne Physique - Documents complémentaires;Tous les clients;Liste des signataires autorisée;309-Liste des Signataires Autorisés |
Personne Physique - Documents complémentaires;Document facultatif;Lettre « Investisseur Averti »;424-Declaration Form for Certified Sophisticated Investors |
Personne Physique - Documents complémentaires;Document facultatif;Lettre « Investisseur Professionnel »;426-Declaration Form for Investment Professionals |
Personne Physique - Documents complémentaires;Document facultatif;Pouvoir (CNI ou passeport des mandataires à fournir);019-Pouvoir mandataire, 120- Pièce identité du ou des mandataires |
`,
    matrix1_morale: `
Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document

Personne Morale - Identification;Tous les clients;Identification de l’entité;005-Identification Personne Morale 2020 |
Personne Morale - Documents complémentaires;Tous les clients;Convention d’entrée en relation de l’entité;006-Convention d'Entrée en Relation PM 2020 |
Personne Morale - Identification des BEE;Tous les clients;Identification Personne Physique (1 par titulaire et BEE);001-Fiche administrative |
Personne Morale - Fiscalité;Tous les clients;Auto-certification (REG/CRS);202-CRS SELF CERTIFICATION |
Personne Morale - Identification des BEE;Tous les clients;Déclaration des BEE (CNI ou passeport);010-Ayant Droit Economique, 401-PI BEE, 406 Registre des BEE |
Personne Morale - Fiscalité;Non-résidents fiscaux monégasques;Attestation Tax Compliance Framework ou Déclaration Fiscale;405-Justificatif complémentaire de conformité fiscale, 999-KYC |
Personne Morale - Questionnaire MIFID;Tous les clients;Questionnaire MIFID;598-Questionnaire MIFID (personne) |
Personne Morale - Fiscalité;Tous les clients;FATCA, W8 BEN;061-QI W9, 063-Convention double imposition acceptée, 078-Convention double imposition refusée |
Personne Morale - Fiscalité;Tous les clients;Autorisation d’échange d’informations B.P.I;311-Autorisation d'échange d'information BPI |
Personne Morale - Identification;Tous les clients;Derniers statuts disponibles de la société;024-Statuts, 124-Status |
Personne Morale - Identification;Tous les clients;Extrait du registre du commerce (daté de moins de 3 mois);025-Registre du commerce, 125-Registre du commerce |
Personne Morale - Revenus et patrimoine;Sociétés auditées ou selon réglementation;Dernier Bilan (audité si applicable);999-KYC |
Personne Morale - Identification des BEE;Sociétés ayant des actionnaires ou bénéficiaires effectifs;Dernier registre des actionnaires et des bénéficiaires effectifs (si applicable);032-Extrait registre actionnaires, 132-Extrait registre actionnaires |
Personne Morale - Identification;Tous les clients;CNI ou passeport(s) en cours de validité de tous les intervenants sur le compte;034-Pièce identité actionnaires |
Personne Morale - Documents complémentaires;Clients souhaitant établir une crédibilité bancaire;Lettre de référence bancaire d’une banque reconnue/acceptable;999-KYC |
Personne Morale - Justificatif de domicile;Tous les clients;Justificatif de domicile récent (daté de moins de 6 mois);062-Attestation certificat, 999-KYC |
Personne Morale - Identification;Tous les clients;Organigramme complet des liens capitalistiques;026-Liste des dirigeants, 126-Liste des dirigeants ,032-registre des acctionnaire, 132-registre des acctionnaire |
Personne Morale - Cas particuliers;Tous les clients;PV de la société autorisant l’ouverture de compte;030-PV ouverture de compte, 130-PV ouverture de compte |
Personne Morale - Identification;Tous les clients;Liste des administrateurs ou gérants (ou trustee) et de leurs pouvoirs;026-Liste des dirigeants, 126-Liste des dirigeants |
Personne Morale - Identification des BEE;Sociétés avec actionnaires ou associés;Extrait du registre des actionnaires ou associés;032-Extrait registre actionnaires, 132-Extrait registre actionnaires |
Personne Morale - Cas particuliers;Trusts ou entités similaires;Document officiel identifiant le(s) fondateur(s) avec passeport certifié;999-KYC, 405-Justificatif complémentaire de conformité fiscale |
Personne Morale - Cas particuliers;Trusts ou entités similaires;Document officiel identifiant le(s) bénéficiaire(s) avec passeport certifié;999-KYC, 405-Justificatif complémentaire de conformité fiscale |
Personne Morale - Fiscalité;Clients non-domestiques à profil de risques LCB-FT élevé;Attestation de conformité fiscale ou autres justificatifs;999-KYC, 405-Justificatif complémentaire de conformité fiscale |
Personne Morale - Fiscalité;Clients non-couverts par un accord d’échange automatique;Mesures d'atténuation du risque;999-KYC, 405-Justificatif complémentaire de conformité fiscale |
Personne Morale - Cas particuliers;Nécessaire pour l'accès au coffre;Procuration pour accès au coffre;041-Procuration pour accès au coffre, 141-Procuration pour accès au coffre |
Personne Morale - Cas particuliers;Nécessaire pour les gérants externes;Procuration spéciale gérant externe;077-Procuration spéciale gérant externe |
`,

    matrix2_physique: `
Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document
    
Personne Physique - Identification;Tous les clients;Pièce d'identité (Passeport, Carte Nationale d’Identité, Permis de conduire, Titre de séjour UE, ou Carte de résident MC);T00217 - Pièce d'identité;Document officiel attestant l'identité du client à l'aide de divers supports d'identification. |
Personne Physique - Justificatif de domicile;Tous les clients;Justificatif de domicile (Taxe d'habitation, Taxe foncière, Avis d'imposition, Factures, Quittance de loyer, Contrat de location résidence principale, ou Certificat de résidence);T00404 - Justificatif de domicile;Document récent prouvant l’adresse de résidence principale du client. |
Personne Physique - Fiscalité;Tous les clients;Formulaire CRS (auto-certification);T00868 - Formulaire CRS;Formulaire d’auto-certification (CRS) attestant de la résidence fiscale du client pour conformité. |
Personne Physique - Fiscalité;Tous les clients;Formulaire FATCA (W8 ou W9 + Waiver);T00878 - Formulaire FATCA;Document destiné à la conformité FATCA. |
Personne Physique - Documents complémentaires;Tous les clients;Convention de compte signée;T00399 - Convention de compte;Convention signée établissant les modalités d'ouverture et de fonctionnement du compte. |
Personne Physique - Documents complémentaires;Tous les clients;Accord d'ouverture de compte;T00399 - Accord d'ouverture de compte;Accord formalisant l’acceptation des conditions d'ouverture de compte. |
Personne Physique - Activité;Tous les clients;Auto-déclaration d'activité (PWA ou fiche déclarative) ou document probant;T01150 - Auto-déclaration d'activité;Déclaration ou preuve attestant de l'activité professionnelle du client. | 
Personne Physique - Revenus;Tous les clients;Auto-déclaration de revenus (PWA ou fiche déclarative) ou document probant;T00471 - Auto-déclaration de revenus;Déclaration ou preuve des revenus du client. |
Personne Physique - Revenus et patrimoine;Uniquement Client LAB 4 et LAB 4 avec PEP/SPO;Justificatif de revenus (fiche de paie, relevé bancaire, ou autre preuve) couvre Autodéclaration de revenus;T00471 - Justificatif de revenus;Preuve (bulletins de salaire, relevés bancaires, etc.) attestant des revenus du client. |
Personne Physique - Revenus et patrimoine;Uniquement Client LAB 4 avec PEP/SPO;Origine de fortune (déclaration patrimoniale signée ou justificatif);T00788 - Justificatif d'origine de patrimoine;Document attestant de l’origine des fonds et de la fortune du client. |
Personne Physique - Revenus et patrimoine;Uniquement Client LAB 4 avec PEP/SPO;Patrimoine : Auto-déclaration signée (PWA ou fiche déclarative) ou document probant;T00788 - Justificatif de patrimoine;Déclaration ou preuve attestant de la composition du patrimoine du client. |
Personne Physique - Cas particuliers;Uniquement Client non ressortissantes de l'UE;Titre de séjour (si applicable);T00248 - Titre de séjour;Document d'autorisation de séjour pour les clients non ressortissants de l'UE. |
Personne Physique - Cas particuliers;Uniquement Client hébergées;Attestation d’hébergement (si hébergé);T00249 - Attestation d'hébergement;Attestation officielle prouvant que le client est hébergé. |
Personne Physique - Documents complémentaires;Obligatoire pour les cas spécifiques de transformation de compte;PV AG avec feuille de présence (si applicable);T00399 - PV AG;Procès-verbal d'Assemblée Générale incluant la feuille de présence, requis dans certains cas de transformation de compte. |
Personne Physique - Double relation;Uniquement Client ayant une double relation;Documentation à jour pour chaque entité (justificatif de moins de 6 mois, extrait du RC de moins de 3 mois, ou dernier PV d’AG);T00590 - Documentation à jour;Ensemble de documents récents attestant de la situation et de l’identité de chaque entité liée au client en cas de double relation. |
Personne Physique - Activité;Uniquement Client LAB 4 avec PEP/SPO;Auto-déclaration signée ou document probant;T01150 - Auto-déclaration d'activité signée;Déclaration d'activité signée confirmant l'activité professionnelle du client dans le cadre LAB 4 avec PEP/SPO. |
Personne Physique - Revenus;Uniquement Client LAB 4;Patrimoine : Auto-déclaration (PWA ou fiche déclarative) ou document probant;T00788 - Justificatif de patrimoine;Déclaration ou preuve attestant de la situation patrimoniale du client LAB 4. |
Personne Physique - Identification;Uniquement Clients Résidents Fiscaux à Monaco;Carte de résident en cours de validité;T00241 - Carte de résident;Document attestant la résidence fiscale à Monaco pour les clients résidents. |
Personne Physique - Imposition;Uniquement Clients Non-Résidents Fiscaux à Monaco;Avis d’imposition/Tax return de moins d’un an;T00474 - Avis d'imposition;Document fiscal récent attestant de l'imposition ou d'une déclaration fiscale pour les non-résidents. |
Personne Physique - Fiscalité;Uniquement Client Français Résidents Fiscaux à Monaco;Documents émis par les services fiscaux monégasques justifiant de la Résidence Fiscale à Monaco;T00472 - Justificatif de Résidence Fiscale;Documents officiels de Monaco prouvant la résidence fiscale pour les clients français. |
Personne Physique - Cas spécial;Uniquement Clients Résidents Monaco qui présentent un lieu de naissance en France;Confirmation des critères de nationalité française (à noter dans le CR d’ouverture de compte);Se référer au document - liste document EER PP 2025;Mention dans le compte-rendu d’ouverture de compte confirmant les critères de nationalité française. |
`,

    matrix2_morale:` 
Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document

Personne Morale - Cas particuliers;Tous les clients;PV d’AG autorisant l’ouverture du compte;T00399 - PV d'AG;Procès-verbal d'Assemblée Générale autorisant l'ouverture du compte pour l'entité. |
Personne Morale - Cas particuliers;Tous les clients;Procès-verbal de la délibération du Conseil d’Administration ou de l’AG précisant les signataires autorisés;T00399 - Procès-verbal;Document du Conseil d’Administration ou AG précisant les signataires habilités à engager l'entité. |
Personne Morale - Identification;Tous les clients;Kbis, EBIS, ou équivalent de moins de 3 mois;T00590 - Kbis;Document officiel récent (Kbis, EBIS ou équivalent) attestant de l'existence légale de l'entité. |
Personne Morale - Identification;Tous les clients;PV avec feuille de présence ou registre d’actionnaire de moins de 3 mois;T00399 - PV AG;Procès-verbal récent avec la feuille de présence ou registre d’actionnaires servant à l’identification de l'entité. |
Personne Morale - Identification;Tous les clients;Statuts;T00230 - Statuts;Document constitutif définissant les règles de fonctionnement et l'organisation de l'entité. |
Personne Morale - Fiscalité;Tous les clients;Liasse fiscale (derniers états financiers ou prévisionnels en cas de création);T00507 - Liasse fiscale;Ensemble des états financiers récents ou prévisionnels permettant l'analyse fiscale de l'entité. |
Personne Morale - Fiscalité;Tous les clients;Auto-certification CRS;T00868 - Auto-certification CRS;Déclaration auto-certifiée CRS confirmant la résidence fiscale de l'entité. |
Personne Morale - Revenus et patrimoine;Tous les clients;Activité : Auto-déclaration (PWA ou fiche déclarative) ou informations à disposition;T01150 - Auto-déclaration d'activité;Déclaration ou preuve des activités de l'entité. |
Personne Morale - Cas particuliers;Uniquement Sociétés monégasques;Extrait du registre des BEE émis par l’expansion économique de Monaco;T02034 - Extrait BEE;Extrait spécifique du registre des bénéficiaires effectifs délivré par l'expansion économique de Monaco. |
Personne Morale - Fiscalité;Uniquement les sociétés non transparentes soumises à l’impôt;Formulaire FATCA W8-BEN-E;T00878 - Formulaire FATCA W8-BEN-E;Formulaire FATCA destiné aux sociétés non transparentes soumises à l'impôt. |
Personne Morale - Fiscalité;Uniquement les sociétés transparentes;Formulaire FATCA W8-IMY pour la structure et W8-BEN pour chaque associé;T00878 - Formulaire FATCA W8-IMY;Formulaire FATCA adapté aux sociétés transparentes avec déclarations distinctes pour la structure et pour chaque associé. |
Personne Morale - Fiscalité;Uniquement les associés US;W9 et WAIVERS pour chaque associé US détenant 10% ou plus du capital;T00878 - Formulaire W9;Formulaire W9 et les dérogations correspondantes pour les associés américains détenant au moins 10 % du capital. |
Personne Morale - Revenus et patrimoine;Tous les clients;Activité : Auto-déclaration (PWA ou fiche déclarative) ou informations à disposition;T01150 - Auto-déclaration d'activité;Déclaration ou information attestant de l'activité de l'entité. |
Personne Morale - Revenus et patrimoine;Uniquement clients LAB 4;Revenus : Documents probants;T00471 - Justificatif de revenus;Documents attestant de manière probante les revenus de l'entité pour les clients LAB 4. |
Personne Morale - Revenus et patrimoine;Uniquement clients LAB 4;Patrimoine : Auto-déclaration (PWA ou fiche déclarative);T00788 - Justificatif de patrimoine;Déclaration ou preuve concernant la composition du patrimoine de l'entité pour les clients LAB 4. |
Personne Morale - Revenus et patrimoine;Uniquement clients LAB 4 avec PEP/SPO;Origine de patrimoine : Auto-déclaration signée (PWA ou fiche déclarative);T00788 - Justificatif d'origine de patrimoine;Auto-déclaration signée attestant de l'origine des fonds de l'entité pour les clients LAB 4 avec PEP/SPO. |
Personne Morale - Revenus et patrimoine;Uniquement clients LAB 4 avec PEP/SPO;Activité : Auto-déclaration signée (PWA ou fiche déclarative);T01150 - Auto-déclaration d'activité signée;Déclaration d'activité signée certifiant l'activité de l'entité pour les clients LAB 4 avec PEP/SPO. |
Personne Morale - Revenus et patrimoine;Uniquement clients LAB 4 avec PEP/SPO;Revenus : Documents probants;T00471 - Justificatif de revenus;Documents probants attestant les revenus de l'entité pour cette catégorie de clients. |
Personne Morale - Revenus et patrimoine;Uniquement clients LAB 4 avec PEP/SPO;Patrimoine : Auto-déclaration signée (PWA ou fiche déclarative);T00788 - Justificatif de patrimoine;Déclaration signée certifiant la composition du patrimoine de l'entité pour les clients LAB 4 avec PEP/SPO. |
Personne Morale - Cas particuliers;Obligatoire pour les PM passives;Questionnaire CBI/RBI;T01153 - Questionnaire CBI/RBI;Questionnaire CBI/RBI requis pour les petites entreprises passives (PM). |
Personne Morale - Identification des BEE;Obligatoire pour toutes les PM;Justificatif d’identité du BEE;T00217 - Pièce d'identité;Document officiel attestant l'identité de chaque bénéficiaire effectif. |
Personne Morale - Identification des BEE;Obligatoire pour toutes les PM;Justificatif de domicile du BEE;T00404 - Justificatif de domicile;Document récent prouvant l'adresse du bénéficiaire effectif. |
Personne Morale - Fiscalité des BEE;Obligatoire pour les BEE CRS passifs;Justificatif de résidence fiscale;T00878 - Documentation FATCA;Documentation FATCA confirmant la résidence fiscale des bénéficiaires effectifs. |
Personne Morale - Checks de notoriété;Obligatoire pour toutes les PM;Vérification via JORDAN sur tous les intervenants;N/A;Procédure de vérification de la notoriété des intervenants via le système JORDAN. |
Personne Morale - Questionnaire S&E;Uniquement sociétés commerciales;Questionnaire S&E (QSE);T01154 - Questionnaire S&E;Questionnaire S&E destiné à évaluer les critères de durabilité et d'efficacité au sein des sociétés commerciales. |
Personne Morale - Questionnaire ABC;Uniquement sociétés commerciales et professions assujetties;Questionnaire ABC;T01155 - Questionnaire ABC;Questionnaire destiné à l'évaluation de la conformité et de l'exposition des sociétés commerciales et des professions assujetties. |


`
};


async function loadMatrices() {
    try {
        const [SGPBphy, SGPBmor, SGRBphy, SGRBmor] = await Promise.all([
            fetch('matrices/SGPBphy.json').then(res => res.json()),
            fetch('matrices/SGPBmor.json').then(res => res.json()),
            fetch('matrices/SGRBphy.json').then(res => res.json()),
            fetch('matrices/SGRBmor.json').then(res => res.json())
        ]);

        appState.matrices = {
            matrix1_physique: SGPBphy,
            matrix1_morale: SGPBmor,
            matrix2_physique: SGRBphy,
            matrix2_morale: SGRBmor
        };
        
        console.log('Matrices chargées avec succès');
    } catch (error) {
        console.error('Erreur lors du chargement des matrices:', error);
        throw error;
    }
}

// Utilitaire pour récupérer le type de client
function getClientType() {
  const selectElement = document.getElementById('clientType');
  return selectElement ? selectElement.value.toLowerCase() : '';
}

// Utilitaire pour formater les données client saisies
function formatClientData(data) {
    if (!data) {
        console.log("Pas de données client disponibles");
        return "Aucune donnée client saisie";
    }
    
    return `DONNÉES CLIENT SAISIES :
Personne : ${data.type || 'Non spécifié'} | 
LAB du client : ${data.lab || 'Non spécifié'} | 
Pays de résidence fiscale : ${data.country || 'Non spécifié'} | 
PEP/SPO : ${data.pep || 'Non spécifié'} |
Précisions spécifiques : ${data.besoins || 'Non spécifié'}`;
}


async function initializeApp() {
    try {
        console.log("Initialisation de l'application...");
        
        // Charger les matrices
        await loadMatrices();
        
        // Reste de l'initialisation
        const requiredElements = [
            'stepIndicator',
            'step1',
            'step2',
            'promptFinalContent',
            'fileInput',
            'toggleSwitch'
        ];
        
        requiredElements.forEach(elementId => {
            if (!document.getElementById(elementId)) {
                console.error(`Element ${elementId} non trouvé dans le DOM`);
            }
        });

        updateStepIndicator();
        updateDirectionToggle();
        showCurrentStep();
        
        console.log("Initialisation terminée avec succès");
    } catch (error) {
        console.error('Erreur lors de l\'initialisation:', error);
        showError('Une erreur est survenue lors de l\'initialisation de l\'application');
    }
}

function setupEventListeners() {

    const toggleSwitch = document.getElementById('toggleSwitch');
    const label1to2 = document.getElementById('label1to2');
    const label2to1 = document.getElementById('label2to1');

    if (toggleSwitch) {
        toggleSwitch.addEventListener('click', function() {
            if (appState.currentStep > 1) return; // Désactiver après l'étape 1
            
            this.classList.toggle('active');
            label1to2.classList.toggle('active');
            label2to1.classList.toggle('active');
            
            appState.direction = this.classList.contains('active') ? '2-to-1' : '1-to-2';
            updateDirectionToggle();
        });
    }

    document.getElementById('toggleSwitch').addEventListener('click', toggleDirection);
    document.getElementById('fileInput').addEventListener('change', handleFileUpload);
    document.getElementById('promptFinalResult').addEventListener('input', validateFinalStep);
    
    // Bouton de téléchargement CSV
    const downloadBtn = document.getElementById('downloadCSVBtn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', downloadCSV);
    }
}

// Direction Toggle
function toggleDirection() {
    if (appState.currentStep > 1) return; // Disable after step 1
    
    appState.direction = appState.direction === '1-to-2' ? '2-to-1' : '1-to-2';
    updateDirectionToggle();
}

function getClientType() {
    const selectElement = document.getElementById('clientType');
    return selectElement ? selectElement.value.toLowerCase() : '';
}

function updateDirectionToggle() {
    const toggle = document.getElementById('toggleSwitch');
    const label1to2 = document.getElementById('label1to2');
    const label2to1 = document.getElementById('label2to1');
    
    if (appState.direction === '1-to-2') {
        toggle.classList.remove('active');
        label1to2.classList.add('active');
        label2to1.classList.remove('active');
    } else {
        toggle.classList.add('active');
        label1to2.classList.remove('active');
        label2to1.classList.add('active');
    }
    
    // Disable toggle after step 1
    if (appState.currentStep > 1) {
        toggle.style.opacity = '0.5';
        toggle.style.cursor = 'not-allowed';
    }
}

// Step Management
function updateStepIndicator() {
    const steps = document.querySelectorAll('.step');
    const lines = document.querySelectorAll('.step-line');
    
    steps.forEach((step, index) => {
        const stepNumber = index + 1;
        step.classList.remove('active', 'completed');
        
        if (stepNumber < appState.currentStep) {
            step.classList.add('completed');
            const circle = step.querySelector('.step-circle');
            circle.innerHTML = '<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20,6 9,17 4,12"/></svg>';
        } else if (stepNumber === appState.currentStep) {
            step.classList.add('active');
            const circle = step.querySelector('.step-circle');
            circle.textContent = stepNumber;
        } else {
            const circle = step.querySelector('.step-circle');
            circle.textContent = stepNumber;
        }
    });
    
    lines.forEach((line, index) => {
        if (index + 1 < appState.currentStep) {
            line.classList.add('completed');
        } else {
            line.classList.remove('completed');
        }
    });
}

function showCurrentStep() {
    // Cacher tous les panneaux
    document.querySelectorAll('.step-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    
    // Afficher le panneau actuel
    document.getElementById(`step${appState.currentStep}`).classList.add('active');
    
    // Gérer l'affichage du toggle de direction
    const currentPanel = document.getElementById(`step${appState.currentStep}`);
    if (currentPanel) {
        currentPanel.classList.add('active');
        
        if (appState.currentStep === 2) {
            generateFinalPrompt();
        }
    } else {
        console.error(`Panel pour l'étape ${appState.currentStep} non trouvé`); // Debug
    }
}

function nextStep() {
    if (appState.currentStep < 2) {
        validateStep2();
        appState.currentStep++;
        updateStepIndicator();
        showCurrentStep();
        
        if (appState.currentStep === 2) {
            console.log("Génération du prompt final...");
            setTimeout(() => {  // Ajout d'un petit délai pour s'assurer que le DOM est prêt
                generateFinalPrompt();
                openSogptPopup();
            }, 100);
        }
    }
}

// File Upload
function handleFileUpload(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const fileType = detectFileType(file.name);
    if (fileType === 'unknown') {
        alert('Format de fichier non supporté. Veuillez utiliser un fichier CSV ou Excel.');
        return;
    }
    
    const reader = new FileReader();
    reader.onload = function(e) {
        const content = e.target.result;
        const processedContent = fileType === 'csv' ? convertCSVToText(content) : formatExcelText(content);
        
        appState.importedFile = {
            name: file.name,
            content: processedContent,
            type: fileType
        };
        console.log("appState.importedFile:", appState.importedFile);
        showFileSuccess();
    };
    
    reader.onerror = function() {
        alert('Erreur lors de la lecture du fichier. Veuillez réessayer.');
    };
    
    reader.readAsText(file);
}

function detectFileType(fileName) {
    const extension = fileName.split('.').pop().toLowerCase();
    if (extension === 'csv') return 'csv';
    if (extension === 'xlsx' || extension === 'xls') return 'excel';
    return 'unknown';
}

function convertCSVToText(csvContent) {

    return csvContent
}

function formatExcelText(content) {
    return `\n${content}`;
}

function showFileSuccess() {
    document.getElementById('fileUploadArea').style.display = 'none';
    document.getElementById('fileSuccess').style.display = 'block';
    document.getElementById('fileName').textContent = appState.importedFile.name;
    
    const preview = appState.importedFile.content.substring(0, 500);
    document.getElementById('filePreview').textContent = preview + (appState.importedFile.content.length > 500 ? '...' : '');
}

// Method Selection
function setupMethodSelection() {
    // Method selection is handled by selectMethod function
}

// Form Validation
function setupFormValidation() {
    // Liste de tous les champs à surveiller
    const fields = ['clientType', 'clientLAB', 'clientPEP', 'clientCountry', 'clientNeeds'];
    
    fields.forEach(fieldId => {
        const element = document.getElementById(fieldId);
        if (element) {
            // Écouter les changements sur chaque champ
            element.addEventListener('change', function() {
                validateStep2();
                console.log(`${fieldId} changed:`, this.value); // Debug
            });
            
            // Pour les champs texte, écouter aussi les saisies
            if (element.type === 'text' || element.tagName.toLowerCase() === 'textarea') {
                element.addEventListener('input', function() {
                    validateStep2();
                    console.log(`${fieldId} input:`, this.value); // Debug
                });
            }
        }
    });
}

// Prompt Validation
function setupPromptValidation() {
    document.getElementById('promptFinalResult').addEventListener('input', validateFinalStep);
}

function validateStep2() {
    // Assurez-vous que clientData existe
    if (!appState.clientData) {
        appState.clientData = {};
    }
    
    // Récupération et stockage des valeurs
    appState.clientData = {
        type: document.getElementById('clientType').value || 'Non spécifié',
        lab: document.getElementById('clientLAB').value || 'Non spécifié',
        country: document.getElementById('clientCountry').value || 'Non spécifié',
        pep: document.getElementById('clientPEP').value || 'Non spécifié',
        besoins: document.getElementById('clientNeeds').value || 'Non spécifié'
    };

    console.log("Client data updated:", appState.clientData); // Debug
}

function validateFinalStep() {
    const result = document.getElementById('promptFinalResult').value.trim();
    if (result.length > 0) {
        document.getElementById('finalStatus').style.display = 'flex';
        appState.promptResults.final = { result: result };
    } else {
        document.getElementById('finalStatus').style.display = 'none';
    }
}

function escapeCSVCell(cell) {
    // Replace any double quotes in the cell with two double quotes,
    // then wrap the cell in double quotes.
    return `"${cell.replace(/"/g, '""')}"`;
}

function downloadCSV() {
    // Get the content from the final result text area
    const textareaContent = document.getElementById('prompt3Result').value;
    
    // Split the text into individual lines
    const lines = textareaContent.split('\n');
    
    // Find the first table block (consecutive lines starting with "|")
    let tableLines = [];
    let inTable = false;
    for (let i = 0; i < lines.length; i++) {
        const trimmed = lines[i].trim();
        if (trimmed.startsWith('|')) {
            inTable = true;
            tableLines.push(trimmed);
        } else {
            if (inTable) {
                // End the table block when consecutive table lines finish
                break;
            }
        }
    }
    
    if (tableLines.length < 3) {
        alert("Le tableau ne semble pas complet.");
        return;
    }
    
    // The first line is the header, the second line is usually the separator, and the remaining lines are data rows
    const headerLine = tableLines[0];
    let headers = headerLine.slice(1, -1).split('|').map(h => h.trim());
    
    // If the first header does not contain "Documents nécessaires", then add it as the first header.
    if (!headers[0].includes("Documents nécessaires")) {
        headers.unshift("Documents nécessaires");
    }
    
    // Clean header values of markdown formatting (remove ** and any leading numbers followed by a dot)
    const cleanHeaders = headers.map(h => h.replace(/\*\*/g, '').replace(/^\d+\.\s*/, ''));
    
    // Process data rows (skip the header and separator rows)
    const dataRows = tableLines.slice(2).map(line => {
        let cols = line.slice(1, -1).split('|').map(col => col.trim());
        // If the number of columns is less than the header length, prepend an empty cell.
        if (cols.length < cleanHeaders.length) {
            cols.unshift("");
        }
        return cols.map(col => col.replace(/\*\*/g, '').replace(/^\d+\.\s*/, ''));
    });
    
    // Build the CSV content using semicolon as the delimiter.
    // Prepend a UTF-8 BOM ("\ufeff") for proper encoding in Excel.
    let csvContent = "\ufeff";
    // Escape each header cell and join using semicolon
    csvContent += cleanHeaders.map(cell => escapeCSVCell(cell)).join(';') + "\n";
    
    // Escape each data cell and join
    dataRows.forEach(row => {
        csvContent += row.map(cell => escapeCSVCell(cell)).join(';') + "\n";
    });
    
    // Create a Blob from the CSV data and trigger a download.
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "tableau_de_correspondance.csv";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}


function generateFinalPrompt() {

    if (!appState.importedFile) {
        console.error("Pas de fichier importé");
        return;
    }

    if (!appState.matrices) {
        console.error("Les matrices ne sont pas encore chargées");
        return;
    }
    
    validateStep2();

    const clientType = getClientType();// "physique" or "morale"
    let matrix = null;
    if (clientType === "morale") {
        matrix = appState.direction === "1-to-2" ? 
            appState.matrices.matrix1_morale : 
            appState.matrices.matrix2_morale;
    } else {
        matrix = appState.direction === "1-to-2" ? 
            appState.matrices.matrix1_physique : 
            appState.matrices.matrix2_physique;
    }
        // Convertir la matrice JSON en format texte
    //const matrix = formatMatrixToString(matrixJson);

    //const formattedMatrix = formatMatrixForPrompt(matrixJson);

    const indication = appState.direction === '1-to-2' ? 
        'Un client souhaite passer de la banque privée à la banque de détail, Il possède déjà des documents à la banque privée.' :
        'Un client souhaite passer de la banque de détail à la banque privée, Il possède déjà des documents à la banque de détail.';


    let matri = "";
    if (clientType === "morale") {
        // Use the morale matrices based on direction
        matrix = appState.direction === "1-to-2" ? matrices.matrix1_morale : matrices.matrix2_morale;
    } else {
        // Default to physique matrices based on direction
        matrix = appState.direction === "1-to-2" ? matrices.matrix1_physique : matrices.matrix2_physique;
    }

    console.log("Client data before formatting:", appState.clientData); 
    
    let dataSource = formatClientData(appState.clientData);
    console.log("Formatted client data:", dataSource);

    const banque = appState.direction === '1-to-2' ? 
        'Banque de détail' : 
        'Banque privée';

    const banque2 = appState.direction === '1-to-2' ?
        'Banque privée':
        'Banque de détail'; 
    
    const indications = appState.direction === '1-to-2' ? 
        'Pour information Dans les documents du client, le type 999-KYC est un type fourre-tout, il peut contenir des documents considérer (Administratif) pour le client. Les document de type 063 ou 078 sont des documents FATCA' :
        '' ;
    
    const prompt = `

    ${formattedMatrix}

Contexte : 

    ## ${indication} ##
Pour cela nous allons identifier les document réutilisable du client que nous avons déjà dans la base de données de la ${banque2}.
Premièrement, on Identifie les documents requis pour une mise en relation dans la ${banque}, 
Puis on identifie les document du client qui pourrais correspondre au différents documents 

    Procède étape par étape.  

    ### étape 1 : ###

À partir de la description du client et de la Matrice, identifie tous les documents nécessaires en fonction des caractéristique du client ci dessous pour établir la mise en relation avec la ${banque2}.
Vérifie soigneusement que tous les documents sont inclus et qu'aucun élément n'est omis.
Identifie la liste exhaustive des documents nécessaires pour ce client. Avec les données et la matrice ci dessous.


    ### Description du client : ###
${dataSource}

### Matrice qui indique les documents nécessaires à fournir en fonction des données du client, documents à séléctionner dans la matrice : ###
${matrix}

### étape 2 : ###

Pour chaque documents nécessaires à fournir à la ${banque} (étape 1) vérifie si il existe un document potentiellement correspondant dans la liste des documents du client ci-dessous. Aide-toi des commentaires sur les numéros-types de la ${banque2} pour mieux identifier les documents du client.
${indication}
Plusieurs Document du client peuvent être considérer pour un même Documents attendus. Ils seront mis en ⚠️à vérifier si c'est le cas. 

### Documents du client : ###
${appState.importedFile.content}

### Commentaires sur les numéros-types de la ${banque2} : ###

-|-|-|-|-|-|-|-|-|-|-|-|

### sortie finale : ###
- Pour chaque document attendu (étape 1), présentez les informations sous forme de tableau avec les colonnes suivantes :
1.	Documents nécessaires : Nom du document attendu de la banque de détail.
2.	Type du document : Référence associée au document de la banque de détail.
3.	Document du client (avec son type) : Document fourni par le client, avec son type (type de la banque privée, Matrice_SGPB).
4.	Statut : Indiquez si le document est "✅ déjà fournis", "❌ à demander" ou "⚠️à vérifier".
5.	Date d'enregistrement : Date d'enregistrement du document fourni par le client.


-	Une liste avec des documents ambigus, nécessitant une analyse humaine car l'identification est floue ou trop compliquée :
    	Nom du document : [Nom du document du client], type du document.
        `;
    
    const promptElement = document.getElementById('promptFinalContent');
    if (promptElement) {
        console.log("Mise à jour du contenu du prompt..."); // Debug
        promptElement.textContent = prompt;
    } else {
        console.error("Element promptFinalContent non trouvé"); // Debug
    }
}

function formatMatrixToString(matrixJson) {
    let result = "Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document\n\n";
    
    matrixJson.forEach(item => {
        result += `${item.Catégorie};${item["Cas où le document est nécessaire"]};${item["Documents nécessaires"]};${item["Type de Document"]}\n`;
    });
    
    return result;
}

// Copy Functionality
function copyPrompt(promptId) {
    let content = '';
    
    switch(promptId) {
        case 'promptFinal': // Changé de 'prompt1' à 'promptFinal' pour correspondre à l'ID dans le HTML
            content = document.getElementById('promptFinalContent').textContent;
            break;
    }
    
    navigator.clipboard.writeText(content).then(() => {
        const button = document.getElementById(`copy${promptId.charAt(0).toUpperCase() + promptId.slice(1)}`);
        const originalText = button.innerHTML;
        
        button.innerHTML = `
            <svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/>
                <polyline points="22,4 12,14.01 9,11.01"/>
            </svg>
            Copié!
        `;
        
        setTimeout(() => {
            button.innerHTML = originalText;
        }, 2000);
    }).catch(err => {
        console.error('Erreur lors de la copie:', err);
        alert('Erreur lors de la copie. Veuillez sélectionner et copier manuellement.');
    });
}


document.getElementById('clientNeeds').addEventListener('input', function() {
    // Initialize the clientData if it doesn't exist.
    if (!appState.clientData) {
        appState.clientData = {};
    }
    // Save the textarea's trimmed value in the client's besoins field.
    appState.clientData.besoins = document.getElementById('clientNeeds').value.trim();
    // If you have a validation function (for instance, validateStep2), you can call it here to update the button state.
    validateFinalStep();
});
document.getElementById('clientCountry').addEventListener('input', function() {
    if (!appState.clientData) {
        appState.clientData = {};
    }
    appState.clientData.country = document.getElementById('clientCountry').value.trim();
    validateFinalStep();
});

function openSogptPopup() {
    document.getElementById('sogptPopup').style.display = 'flex';
}
function closeSogptPopup() {
    document.getElementById('sogptPopup').style.display = 'none';
}

function openGpt4Popup() {
    document.getElementById('gpt4Popup').style.display = 'flex';
}
function closeGpt4Popup() {
    document.getElementById('gpt4Popup').style.display = 'none';
}

// Un seul événement DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
    console.log("Démarrage de l'application...");
    initializeApp().catch(error => {
        console.error('Erreur lors du démarrage:', error);
    });
});

// Fonction utilitaire pour afficher les erreurs
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: #ff4444;
        color: white;
        padding: 15px 30px;
        border-radius: 5px;
        z-index: 1000;
    `;
    errorDiv.textContent = message;
    document.body.appendChild(errorDiv);

    setTimeout(() => errorDiv.remove(), 5000);
}
