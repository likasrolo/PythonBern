import { useState } from "react";

export default function Newsletter() {
  const [step, setStep] = useState(1);
  const [files, setFiles] = useState<{ html: File | null; excel: File | null }>({
    html: null,
    excel: null
  });
  const [conseillerName, setConseillerName] = useState("");

  const handleFileChange = (type: 'html' | 'excel', event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFiles(prev => ({ ...prev, [type]: file }));
    }
  };

  const handleProcess = () => {
    if (files.html && files.excel && conseillerName) {
      setStep(2);
    }
  };

  const defaultTitles = [
    'BHP ( Market-Perform vs Outperform, TP 1900p vs 2000p)',
    'Défense',
    'Telco France',
    'Eco Australie',
    'Eco Chine',
    'Centrica (=)',
    'Equinor (+)',
    'Kering (=)',
    'Vodafone (=)',
    'Land Securities',
    'Aramis (=/+)',
    'H&M (Underperform, TP: 110SEK)',
    'Conviction Thinking',
    'Equity Strategy',
    'Covered Bonds Special'
  ];

  const generatePrompt = (sectionIndex: number) => {
    return `À partir de la liste des instruments d'un ou plusieurs clients et d'une newsletter, trouve les correspondances entre les instruments des clients et les titres de la newsletter.

Section ${sectionIndex + 1}:

Voici la liste des titres de la newsletter: 
${JSON.stringify(defaultTitles, null, 2)}

Ta sortie se divise en deux parties : 
- La première consiste à me renvoyer une liste avec les numéros de client associée correspondante aux titres.
- La seconde un résumé de 5 lignes maximum pour indiquer les correspondances trouvées.
Le tout séparé par des tirets "---".

Pour la liste : 
- Elle aura en index i le numéro des clients correspondant au titre d'index i dans la liste des titres.
- Pour les titres précis comme des actions/entreprises associe un numéro de client uniquement si il possède un instrument explicite à cette action entreprise.

Exemple de sortie : 
[['MC209710','MC987091'],[],[MC2907309],[],[],...]
--------
Résumé des correspondances trouvées pour cette section.`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert("Prompt copié dans le presse-papier !");
  };

  if (step === 1) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-3xl font-bold mb-8 text-center">
          Traitement Newsletter Personnalisée
        </h1>
        
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <h3 className="font-semibold mb-4">Newsletter HTML</h3>
            <input
              type="file"
              accept=".html,.htm"
              onChange={(e) => handleFileChange('html', e)}
              className="mb-4"
            />
            {files.html && (
              <p className="text-green-600">✓ {files.html.name}</p>
            )}
          </div>
          
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <h3 className="font-semibold mb-4">Portfolio Excel</h3>
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={(e) => handleFileChange('excel', e)}
              className="mb-4"
            />
            {files.excel && (
              <p className="text-green-600">✓ {files.excel.name}</p>
            )}
          </div>
        </div>

        <div className="mb-8">
          <label className="block font-semibold mb-2">Nom du Conseiller</label>
          <input
            type="text"
            value={conseillerName}
            onChange={(e) => setConseillerName(e.target.value)}
            placeholder="Ex: ROLLAND JEAN-MARC"
            className="w-full p-3 border border-gray-300 rounded-lg"
          />
        </div>

        <div className="text-center">
          <button
            onClick={handleProcess}
            disabled={!files.html || !files.excel || !conseillerName.trim()}
            className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold disabled:bg-gray-400 disabled:cursor-not-allowed hover:bg-blue-700"
          >
            Lancer le traitement
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-8 text-center">
        Génération des Prompts
      </h1>
      
      <div className="mb-6">
        <div className="bg-blue-100 border border-blue-300 rounded-lg p-4">
          <h3 className="font-semibold text-blue-800 mb-2">Instructions:</h3>
          <ol className="text-blue-700 space-y-1">
            <li>1. Copiez chaque prompt généré</li>
            <li>2. Collez-le dans votre IA (ChatGPT, Claude, etc.)</li>
            <li>3. Copiez la réponse de l'IA dans la zone de texte correspondante</li>
            <li>4. Répétez pour toutes les sections</li>
          </ol>
        </div>
      </div>

      <div className="space-y-6">
        {[1, 2, 3].map((sectionNum, index) => (
          <div key={sectionNum} className="border border-gray-200 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold">Section {sectionNum}</h3>
              <span className="bg-gray-100 px-3 py-1 rounded-full text-sm">
                ~33 clients
              </span>
            </div>
            
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="font-medium">Prompt généré pour l'IA:</label>
                  <button
                    onClick={() => copyToClipboard(generatePrompt(index))}
                    className="bg-gray-600 text-white px-4 py-2 rounded hover:bg-gray-700 text-sm"
                  >
                    📋 Copier
                  </button>
                </div>
                <textarea
                  value={generatePrompt(index)}
                  readOnly
                  className="w-full h-40 p-3 border border-gray-300 rounded font-mono text-sm bg-gray-50"
                />
              </div>

              <div>
                <label className="block font-medium mb-2">
                  Réponse de l'IA (collez ici):
                </label>
                <textarea
                  placeholder="Collez la réponse de l'IA ici..."
                  className="w-full h-24 p-3 border border-gray-300 rounded"
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-8 space-x-4">
        <button
          onClick={() => setStep(1)}
          className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700"
        >
          ← Retour
        </button>
        <button className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700">
          📄 Générer Newsletter Finale
        </button>
      </div>
    </div>
  );
}