import { useState } from "react";
import { DirectionToggle } from "@/components/direction-toggle";
import { ClientForm, type ClientData } from "@/components/client-form";
import { FileUpload } from "@/components/file-upload";
import { PromptDisplay } from "@/components/prompt-display";
import { AIResults } from "@/components/ai-results";
import { getMatrix } from "@/lib/matrices";
import { type FileProcessResult } from "@/lib/file-processor";
import { Brain, Zap } from "lucide-react";

type Step = 1 | 2;

export default function Passporting() {
  const [currentStep, setCurrentStep] = useState<Step>(1);
  const [direction, setDirection] = useState<'gp-to-bdd' | 'bdd-to-gp'>('gp-to-bdd');
  const [clientData, setClientData] = useState<ClientData>({
    type: '',
    lab: '1',
    country: '',
    pep: 'non',
    needs: ''
  });
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [fileContent, setFileContent] = useState<string>('');
  const [generatedPrompt, setGeneratedPrompt] = useState<string>('');

  const generatePrompt = () => {
    if (!clientData.type || !fileContent) return '';

    const matrix = getMatrix(direction, clientData.type as 'physique' | 'morale');
    const directionName = direction === 'gp-to-bdd' 
      ? 'Gestion Privée vers Banque de Détail' 
      : 'Banque de Détail vers Gestion Privée';
    const personTypeName = clientData.type === 'physique' ? 'Personne Physique' : 'Personne Morale';

    const prompt = `Analyse des documents client pour le passporting bancaire

CONTEXTE:
- Direction: ${directionName}
- Type de client: ${personTypeName}
- LAB: ${clientData.lab}
- Pays de résidence fiscale: ${clientData.country || 'Non spécifié'}
- PEP/SPO: ${clientData.pep}
${clientData.needs ? `- Spécificités: ${clientData.needs}` : ''}

MATRICE DE RÉFÉRENCE:
${matrix}

DOCUMENTS CLIENT À ANALYSER:
${fileContent}

INSTRUCTIONS:
1. Analysez la liste des documents fournis par le client
2. Comparez avec la matrice de référence pour identifier les documents manquants
3. Identifiez les documents réutilisables pour le passporting
4. Créez un tableau synthétique avec les colonnes suivantes:
   - Document requis
   - Statut (Présent/Manquant/À vérifier)
   - Type de document (code)
   - Réutilisable (Oui/Non)
   - Commentaires

5. Fournissez des recommandations spécifiques basées sur le profil client (LAB, PEP, pays de résidence)

Merci de fournir une analyse détaillée et un tableau structuré.`;

    return prompt;
  };

  const handleFileProcessed = (file: File, result: FileProcessResult) => {
    setUploadedFile(file);
    setFileContent(result.content);
  };

  const handleContinue = () => {
    if (!clientData.type) {
      alert('Veuillez sélectionner le type de personne.');
      return;
    }
    if (!uploadedFile) {
      alert('Veuillez importer un fichier.');
      return;
    }

    const prompt = generatePrompt();
    setGeneratedPrompt(prompt);
    setCurrentStep(2);
  };

  const handleResultsChange = (results: string, hasTable: boolean) => {
    // Handle results change if needed
  };

  const handleReset = () => {
    if (confirm('Êtes-vous sûr de vouloir recommencer ? Toutes les données seront perdues.')) {
      setCurrentStep(1);
      setDirection('gp-to-bdd');
      setClientData({
        type: '',
        lab: '1',
        country: '',
        pep: 'non',
        needs: ''
      });
      setUploadedFile(null);
      setFileContent('');
      setGeneratedPrompt('');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center justify-center gap-4">
            <div className="relative">
              <Brain className="w-8 h-8 text-primary" />
              <Zap className="w-4 h-4 text-yellow-500 absolute -top-1 -right-1" />
            </div>
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900">Passporting Monaco</h1>
              <p className="text-sm text-gray-600">
                Identifiez les documents réutilisables pour la mise en relation
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Step Indicator */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center">
            <div className={`flex items-center justify-center w-10 h-10 rounded-full font-semibold text-sm ${
              currentStep === 1 
                ? 'bg-primary text-white' 
                : 'bg-green-600 text-white'
            }`}>
              1
            </div>
            <div className={`w-16 h-0.5 ${currentStep === 2 ? 'bg-green-600' : 'bg-gray-300'}`} />
            <div className={`flex items-center justify-center w-10 h-10 rounded-full font-semibold text-sm ${
              currentStep === 2 
                ? 'bg-primary text-white' 
                : 'bg-gray-300 text-gray-500'
            }`}>
              2
            </div>
          </div>
        </div>

        {/* Step Content */}
        {currentStep === 1 && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Étape 1 : Import de l'extraction des documents client
              </h2>
              <p className="text-gray-600">
                Importez l'extraction Excel ou CSV contenant les documents du client à analyser
              </p>
            </div>

            <DirectionToggle
              direction={direction}
              onDirectionChange={setDirection}
              clientType={clientData.type}
            />

            <ClientForm
              clientData={clientData}
              onClientDataChange={setClientData}
            />

            <FileUpload
              onFileProcessed={handleFileProcessed}
              onContinue={handleContinue}
            />
          </div>
        )}

        {currentStep === 2 && (
          <div>
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Étape 2 : Génération et traitement du prompt
              </h2>
              <p className="text-gray-600">
                Copiez le prompt généré, utilisez-le dans soGPT, puis collez le résultat
              </p>
            </div>

            <PromptDisplay prompt={generatedPrompt} />

            <div className="mt-6">
              <AIResults 
                onResultsChange={handleResultsChange}
                onReset={handleReset}
              />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
