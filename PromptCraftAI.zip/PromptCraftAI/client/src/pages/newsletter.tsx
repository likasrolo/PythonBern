import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Upload, FileText, FileSpreadsheet, Copy, Download, ChevronRight } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { NewsletterProcess } from "@shared/schema";

interface FileUploadZone {
  title: string;
  description: string;
  icon: React.ReactNode;
  accept: string;
  type: 'html' | 'excel';
}

const fileZones: FileUploadZone[] = [
  {
    title: "Newsletter HTML",
    description: "Glissez-déposez votre fichier HTML de newsletter ici",
    icon: <FileText className="w-8 h-8" />,
    accept: ".html,.htm",
    type: 'html'
  },
  {
    title: "Portfolio Excel",
    description: "Glissez-déposez votre fichier Excel de portefeuille client ici",
    icon: <FileSpreadsheet className="w-8 h-8" />,
    accept: ".xlsx,.xls",
    type: 'excel'
  }
];

export default function Newsletter() {
  const [files, setFiles] = useState<{ html: File | null; excel: File | null }>({
    html: null,
    excel: null
  });
  const [conseillerName, setConseillerName] = useState("");
  const [currentProcess, setCurrentProcess] = useState<NewsletterProcess | null>(null);
  const [step, setStep] = useState(1);
  const [sectionResponses, setSectionResponses] = useState<Record<number, string>>({});
  const fileInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createProcessMutation = useMutation({
    mutationFn: async (data: { name: string; conseillerName: string; htmlContent: string; excelContent: string }) => 
      apiRequest("/api/newsletter/create", {
        method: "POST",
        body: JSON.stringify(data),
      }),
    onSuccess: (process) => {
      setCurrentProcess(process);
      setStep(2);
      queryClient.invalidateQueries({ queryKey: ["/api/newsletter/list"] });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de créer le processus de newsletter",
        variant: "destructive",
      });
    },
  });

  const { data: sections } = useQuery({
    queryKey: ["/api/newsletter/sections", currentProcess?.id],
    enabled: !!currentProcess?.id,
  });

  const handleFileSelect = (type: 'html' | 'excel') => {
    fileInputRefs.current[type]?.click();
  };

  const handleFileChange = (type: 'html' | 'excel', event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setFiles(prev => ({ ...prev, [type]: file }));
    }
  };

  const handleDrop = (type: 'html' | 'excel', event: React.DragEvent) => {
    event.preventDefault();
    const file = event.dataTransfer.files[0];
    if (file) {
      setFiles(prev => ({ ...prev, [type]: file }));
    }
  };

  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  };

  const handleProcessFiles = async () => {
    if (!files.html || !files.excel || !conseillerName.trim()) {
      toast({
        title: "Fichiers manquants",
        description: "Veuillez sélectionner tous les fichiers et saisir le nom du conseiller",
        variant: "destructive",
      });
      return;
    }

    try {
      const htmlContent = await readFileAsText(files.html);
      const excelContent = await readFileAsText(files.excel);
      
      createProcessMutation.mutate({
        name: `Newsletter ${new Date().toLocaleDateString()}`,
        conseillerName,
        htmlContent,
        excelContent,
      });
    } catch (error) {
      toast({
        title: "Erreur de lecture",
        description: "Impossible de lire les fichiers",
        variant: "destructive",
      });
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copié",
      description: "Le prompt a été copié dans le presse-papier",
    });
  };

  const handleSectionResponse = (sectionId: number, response: string) => {
    setSectionResponses(prev => ({
      ...prev,
      [sectionId]: response
    }));
  };

  const renderFileUploadZone = (zone: FileUploadZone) => {
    const hasFile = files[zone.type];
    
    return (
      <Card
        key={zone.type}
        className={`border-2 border-dashed transition-colors cursor-pointer ${
          hasFile 
            ? 'border-green-500 bg-green-50 dark:bg-green-950' 
            : 'border-gray-300 hover:border-gray-400'
        }`}
        onClick={() => handleFileSelect(zone.type)}
        onDrop={(e) => handleDrop(zone.type, e)}
        onDragOver={(e) => e.preventDefault()}
      >
        <CardContent className="flex flex-col items-center justify-center p-8 text-center">
          <div className={`mb-4 ${hasFile ? 'text-green-600' : 'text-gray-400'}`}>
            {zone.icon}
          </div>
          <h3 className="font-semibold mb-2">{zone.title}</h3>
          <p className="text-sm text-gray-600 mb-4">{zone.description}</p>
          {hasFile ? (
            <Badge variant="secondary" className="bg-green-100 text-green-800">
              {hasFile.name}
            </Badge>
          ) : (
            <Badge variant="outline">Cliquez ou glissez-déposez</Badge>
          )}
          <input
            ref={(el) => fileInputRefs.current[zone.type] = el}
            type="file"
            accept={zone.accept}
            onChange={(e) => handleFileChange(zone.type, e)}
            className="hidden"
          />
        </CardContent>
      </Card>
    );
  };

  if (step === 1) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold mb-4">Traitement Newsletter Personnalisée</h1>
            <p className="text-gray-600">
              Uploadez votre newsletter HTML et votre fichier Excel de portefeuille client pour générer des prompts personnalisés
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-8">
            {fileZones.map(renderFileUploadZone)}
          </div>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Configuration</CardTitle>
              <CardDescription>
                Saisissez les informations nécessaires pour le traitement
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="conseiller">Nom du Conseiller</Label>
                  <Input
                    id="conseiller"
                    value={conseillerName}
                    onChange={(e) => setConseillerName(e.target.value)}
                    placeholder="Ex: ROLLAND JEAN-MARC"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-center">
            <Button
              onClick={handleProcessFiles}
              disabled={!files.html || !files.excel || !conseillerName.trim() || createProcessMutation.isPending}
              size="lg"
            >
              {createProcessMutation.isPending ? (
                <>Processing...</>
              ) : (
                <>
                  Lancer le traitement
                  <ChevronRight className="ml-2 w-4 h-4" />
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4">Génération des Prompts</h1>
          <p className="text-gray-600">
            Copiez les prompts pour chaque section et collez les réponses de l'IA
          </p>
        </div>

        <Progress value={75} className="mb-8" />

        <div className="space-y-6">
          {sections?.map((section: any, index: number) => (
            <Card key={section.id}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Section {section.sectionNumber}
                  <Badge variant="outline">
                    {section.totalClients} clients
                  </Badge>
                </CardTitle>
                <CardDescription>
                  {section.totalInstruments} instruments au total
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <Label>Prompt généré pour l'IA</Label>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyToClipboard(section.sectionPrompt)}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copier
                    </Button>
                  </div>
                  <Textarea
                    value={section.sectionPrompt}
                    readOnly
                    className="h-32 font-mono text-sm"
                  />
                </div>

                <div>
                  <Label htmlFor={`response-${section.id}`}>
                    Réponse de l'IA (collez ici)
                  </Label>
                  <Textarea
                    id={`response-${section.id}`}
                    value={sectionResponses[section.id] || ""}
                    onChange={(e) => handleSectionResponse(section.id, e.target.value)}
                    placeholder="Collez la réponse de l'IA ici..."
                    className="h-24"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="flex justify-center mt-8 space-x-4">
          <Button variant="outline" onClick={() => setStep(1)}>
            Retour
          </Button>
          <Button>
            <Download className="w-4 h-4 mr-2" />
            Générer Newsletter Finale
          </Button>
        </div>
      </div>
    </div>
  );
}