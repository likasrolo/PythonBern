export function exportToCSV(data: string, filename: string = 'passporting_analysis.csv'): void {
  try {
    // Convert table data to proper CSV format
    let csvContent = data.replace(/\|/g, ';');
    
    // Ensure proper CSV formatting
    const lines = csvContent.split('\n').filter(line => line.trim());
    const formattedLines = lines.map(line => {
      // Split by semicolon and ensure proper quoting
      const cells = line.split(';').map(cell => {
        const trimmed = cell.trim();
        // Quote cells that contain commas, quotes, or newlines
        if (trimmed.includes(',') || trimmed.includes('"') || trimmed.includes('\n')) {
          return `"${trimmed.replace(/"/g, '""')}"`;
        }
        return trimmed;
      });
      return cells.join(';');
    });
    
    csvContent = formattedLines.join('\n');
    
    // Create blob and download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    
    const timestamp = new Date().toISOString().split('T')[0];
    const finalFilename = filename.includes('.') 
      ? filename.replace(/\.(csv|txt)$/i, `_${timestamp}.csv`)
      : `${filename}_${timestamp}.csv`;
    
    link.setAttribute('href', url);
    link.setAttribute('download', finalFilename);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Erreur lors de l\'export CSV:', error);
    throw new Error('Erreur lors de la génération du fichier CSV');
  }
}

export function extractTableFromText(text: string): string | null {
  const lines = text.split('\n');
  const tableLines = lines.filter(line => 
    line.includes('|') || 
    line.includes(';') || 
    (line.includes('-') && line.includes('Présent')) ||
    (line.includes('-') && line.includes('Manquant')) ||
    (line.includes('Document') && line.includes('Statut')) ||
    line.match(/^\s*\|.*\|\s*$/) // Table rows with pipes
  );
  
  if (tableLines.length > 2) {
    return tableLines.join('\n');
  }
  
  return null;
}
