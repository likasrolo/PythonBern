export const matrices = {
  'gp-to-bdd': {
    physique: `Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document

Personne Physique - Identification;Tous les clients;Identification Personne Physique;001-Identification Personne Physique 2020 |
Personne Physique - Documents complémentaires;Tous les clients;Convention d'entrée en relation Personne Physique;002-Convention d'Entrée en Relation PP 2020 |
Personne Physique - Fiscalité;Tous les clients;Auto-certification de résidence fiscale;029-Déclaration de résidence fiscale,202-CRS SELF CERTIFICATION |
Personne Physique - Fiscalité;Tous les clients;Questionnaire MIFID;598-Questionnaire MIFID |
Personne Physique - Fiscalité;Tous les clients;FATCA, W8 BEN;061-QI W9,063-Convention double imposition acceptée, 078-Convention double imposition refusée |
Personne Physique - Identifiaction;Tous les clients;Pièce d'identité en cours de validité du titulaire;020-Pièce identité du ou des mandataires, 034-Pièce identité actionnaires |
Personne Physique - ;Tous les clients;Lettre de référence bancaire;999-KYC |
Personne Physique - Justificatif de domicile;Tous les clients;Justificatif de domicile récent (< 6 mois);062-Attestation certificat |
Personne Physique - Revenus et patrimoine;Tous les Clients;Justificatif d'origine de la fortune;999-KYC, 815-Origine de la fortune |
Personne Physique - Revenus et patrimoine;Tous les clients;Justificatif de revenus;999-KYC, 816-Revenus |
Personne Physique - Revenus et patrimoine;Tous les clients;Audit Patrimonial ou Déclaration de Patrimoine;198-Audit patrimonial, 817-Patrimoine |`,
    morale: `Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document

Personne Morale - Identification;Tous les clients;Identification de l'entité;005-Identification Personne Morale 2020 |
Personne Morale - Documents complémentaires;Tous les clients;Convention d'entrée en relation de l'entité;006-Convention d'Entrée en Relation PM 2020 |
Personne Morale - Identification des BEE;Tous les clients;Identification Personne Physique (1 par titulaire et BEE);001-Fiche administrative |
Personne Morale - Fiscalité;Tous les clients;Auto-certification (REG/CRS);202-CRS SELF CERTIFICATION |
Personne Morale - Identification des BEE;Tous les clients;Déclaration des BEE (CNI ou passeport);010-Ayant Droit Economique, 401-PI BEE, 406 Registre des BEE |
Personne Morale - Fiscalité;Non-résidents fiscaux monégasques;Attestation Tax Compliance Framework ou Déclaration Fiscale;405-Justificatif complémentaire de conformité fiscale, 999-KYC |
Personne Morale - Questionnaire MIFID;Tous les clients;Questionnaire MIFID;598-Questionnaire MIFID (personne) |
Personne Morale - Fiscalité;Tous les clients;FATCA, W8 BEN;061-QI W9, 063-Convention double imposition acceptée, 078-Convention double imposition refusée |`
  },
  'bdd-to-gp': {
    physique: `Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document
     
Personne Physique - Identification;Tous les clients;Pièce d'identité (Passeport, Carte Nationale d'Identité, Permis de conduire, Titre de séjour UE, ou Carte de résident MC);T00217 - Pièce d'identité;Document officiel attestant l'identité du client à l'aide de divers supports d'identification. |
Personne Physique - Justificatif de domicile;Tous les clients;Justificatif de domicile (Taxe d'habitation, Taxe foncière, Avis d'imposition, Factures, Quittance de loyer, Contrat de location résidence principale, ou Certificat de résidence);T00404 - Justificatif de domicile;Document récent prouvant l'adresse de résidence principale du client. |
Personne Physique - Fiscalité;Tous les clients;Formulaire CRS (auto-certification);T00868 - Formulaire CRS;Formulaire d'auto-certification (CRS) attestant de la résidence fiscale du client pour conformité. |
Personne Physique - Fiscalité;Tous les clients;Formulaire FATCA (W8 ou W9 + Waiver);T00878 - Formulaire FATCA;Document destiné à la conformité FATCA. |
Personne Physique - Documents complémentaires;Tous les clients;Convention de compte signée;T00399 - Convention de compte;Convention signée établissant les modalités d'ouverture et de fonctionnement du compte. |
Personne Physique - Documents complémentaires;Tous les clients;Accord d'ouverture de compte;T00399 - Accord d'ouverture de compte;Accord formalisant l'acceptation des conditions d'ouverture de compte. |
Personne Physique - Activité;Tous les clients;Auto-déclaration d'activité (PWA ou fiche déclarative) ou document probant;T01150 - Auto-déclaration d'activité;Déclaration ou preuve attestant de l'activité professionnelle du client. |`,
    morale: `Catégorie;Cas où le document est nécessaire;Documents nécessaires;Type de Document

Personne Morale - Identification;Tous les clients;Extrait du registre de commerce récent;T00301 - Extrait registre commerce;Document officiel attestant de l'existence légale de l'entité. |
Personne Morale - Identification;Tous les clients;Statuts de la société;T00302 - Statuts société;Document juridique définissant la structure et le fonctionnement de l'entité. |
Personne Morale - Identification;Tous les clients;Liste des dirigeants;T00303 - Liste dirigeants;Document identifiant les personnes habilitées à représenter l'entité. |
Personne Morale - Fiscalité;Tous les clients;Formulaire CRS entité;T00868 - Formulaire CRS entité;Auto-certification fiscale pour les personnes morales. |`
  }
};

export function getMatrix(direction: 'gp-to-bdd' | 'bdd-to-gp', clientType: 'physique' | 'morale'): string {
  return matrices[direction]?.[clientType] || '';
}

export function getMatrixName(direction: 'gp-to-bdd' | 'bdd-to-gp'): string {
  return direction === 'gp-to-bdd' 
    ? 'Gestion Privée vers Banque de Détail' 
    : 'Banque de Détail vers Gestion Privée';
}
