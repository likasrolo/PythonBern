export interface FileProcessResult {
  content: string;
  preview: string;
}

export async function processFile(file: File): Promise<FileProcessResult> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = function(e) {
      try {
        let content = '';
        
        if (file.name.endsWith('.csv')) {
          content = e.target?.result as string;
        } else if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
          // For Excel files, we'll need to use a library like xlsx
          // For now, we'll handle it as text and provide instructions
          content = e.target?.result as string;
        }
        
        const preview = content.substring(0, 500) + (content.length > 500 ? '...' : '');
        
        resolve({
          content,
          preview
        });
      } catch (error) {
        reject(new Error(`Erreur lors de la lecture du fichier: ${error}`));
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Erreur lors de la lecture du fichier'));
    };
    
    if (file.name.endsWith('.csv')) {
      reader.readAsText(file);
    } else {
      reader.readAsText(file); // Simplified for now
    }
  });
}
