import { Switch, Route, Link, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import Newsletter from "./pages/newsletter-simple";

function Navigation() {
  const [location] = useLocation();
  
  return (
    <nav className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <h1 className="text-xl font-bold text-gray-900">Monaco Banking Tools</h1>
            </div>
            <div className="ml-6 flex space-x-8">
              <Link href="/">
                <button 
                  className={`px-4 py-2 rounded-md ${
                    location === "/" 
                      ? "bg-blue-600 text-white" 
                      : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                  }`}
                >
                  Passporting
                </button>
              </Link>
              <Link href="/newsletter">
                <button 
                  className={`px-4 py-2 rounded-md ${
                    location === "/newsletter" 
                      ? "bg-blue-600 text-white" 
                      : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                  }`}
                >
                  Newsletter
                </button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}

function NotFound() {
  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <div className="text-center">
        <h1 className="text-6xl font-bold text-gray-900">404</h1>
        <p className="mt-4 text-xl text-gray-600">Page non trouvée</p>
        <Link href="/">
          <button className="mt-6 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
            Retour à l'accueil
          </button>
        </Link>
      </div>
    </div>
  );
}

function PassportingPlaceholder() {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-8 text-center">Passporting</h1>
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 text-center">
        <p className="text-blue-800">
          La fonctionnalité Passporting est disponible dans l'application principale.
        </p>
        <p className="text-blue-600 mt-2">
          Utilisez l'onglet Newsletter pour tester la nouvelle fonctionnalité.
        </p>
      </div>
    </div>
  );
}

function Router() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <div className="py-8">
        <Switch>
          <Route path="/" component={PassportingPlaceholder} />
          <Route path="/newsletter" component={Newsletter} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
    </QueryClientProvider>
  );
}

export default App;