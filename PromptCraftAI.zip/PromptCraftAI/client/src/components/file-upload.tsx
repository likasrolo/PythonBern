import { useState, useRef } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, CheckCircle } from "lucide-react";
import { processFile, type FileProcessResult } from "@/lib/file-processor";

interface FileUploadProps {
  onFileProcessed: (file: File, result: FileProcessResult) => void;
  onContinue: () => void;
}

export function FileUpload({ onFileProcessed, onContinue }: FileUploadProps) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [fileResult, setFileResult] = useState<FileProcessResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (file: File) => {
    setError(null);
    setIsProcessing(true);
    
    try {
      const result = await processFile(file);
      setUploadedFile(file);
      setFileResult(result);
      onFileProcessed(file, result);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Erreur lors du traitement du fichier');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const resetFile = () => {
    setUploadedFile(null);
    setFileResult(null);
    setError(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  if (uploadedFile && fileResult && !error) {
    return (
      <Card className="p-6">
        <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg mb-4">
          <CheckCircle className="w-6 h-6 text-green-600" />
          <div>
            <h4 className="font-semibold text-green-800">Fichier importé avec succès</h4>
            <p className="text-sm text-green-600">{uploadedFile.name}</p>
          </div>
        </div>
        
        <div className="mb-4">
          <h5 className="font-medium text-gray-900 mb-2">Aperçu du contenu :</h5>
          <div className="bg-white border border-gray-200 rounded-lg p-4 max-h-40 overflow-y-auto">
            <pre className="text-xs text-gray-700 whitespace-pre-wrap">{fileResult.preview}</pre>
          </div>
        </div>
        
        <div className="flex gap-4">
          <Button variant="outline" onClick={resetFile}>
            Remplacer le fichier
          </Button>
          <Button onClick={onContinue}>
            Continuer vers l'IA
          </Button>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6">
      <div
        className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors cursor-pointer ${
          isDragOver ? 'border-primary bg-blue-50' : 'border-gray-300 hover:border-primary'
        } ${isProcessing ? 'opacity-50 pointer-events-none' : ''}`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
      >
        <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          {isProcessing ? 'Traitement du fichier...' : 'Glisser-déposer votre fichier ici'}
        </h3>
        <p className="text-gray-600 mb-4">ou cliquez pour sélectionner un fichier</p>
        
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          className="hidden"
          onChange={handleFileInput}
        />
        
        <Button 
          type="button" 
          disabled={isProcessing}
          onClick={(e) => {
            e.stopPropagation();
            fileInputRef.current?.click();
          }}
        >
          <Upload className="w-5 h-5 mr-2" />
          Sélectionner un fichier
        </Button>
        
        <p className="text-xs text-gray-500 mt-2">Formats supportés : CSV, Excel (.xlsx, .xls)</p>
        
        {error && (
          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-sm text-red-600">{error}</p>
          </div>
        )}
      </div>
    </Card>
  );
}
