import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export interface ClientData {
  type: string;
  lab: string;
  country: string;
  pep: string;
  needs: string;
}

interface ClientFormProps {
  clientData: ClientData;
  onClientDataChange: (data: ClientData) => void;
}

export function ClientForm({ clientData, onClientDataChange }: ClientFormProps) {
  const updateField = (field: keyof ClientData, value: string) => {
    onClientDataChange({
      ...clientData,
      [field]: value
    });
  };

  return (
    <Card className="p-6 mb-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations client</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
          <Label htmlFor="clientType" className="block text-sm font-medium text-gray-700 mb-2">
            Personne
          </Label>
          <Select value={clientData.type} onValueChange={(value) => updateField('type', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Choisir..." />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="physique">Physique</SelectItem>
              <SelectItem value="morale">Morale</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="clientLAB" className="block text-sm font-medium text-gray-700 mb-2">
            LAB du client
          </Label>
          <Select value={clientData.lab} onValueChange={(value) => updateField('lab', value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">1</SelectItem>
              <SelectItem value="2">2</SelectItem>
              <SelectItem value="3">3</SelectItem>
              <SelectItem value="4">4</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div>
          <Label htmlFor="clientCountry" className="block text-sm font-medium text-gray-700 mb-2">
            Pays de résidence fiscale
          </Label>
          <Input
            id="clientCountry"
            value={clientData.country}
            onChange={(e) => updateField('country', e.target.value)}
            placeholder="Saisir le pays"
          />
        </div>
        
        <div>
          <Label htmlFor="clientPEP" className="block text-sm font-medium text-gray-700 mb-2">
            PEP/SPO
          </Label>
          <Select value={clientData.pep} onValueChange={(value) => updateField('pep', value)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="non">Non</SelectItem>
              <SelectItem value="oui">Oui</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div>
        <Label htmlFor="clientNeeds" className="block text-sm font-medium text-gray-700 mb-2">
          Précisions spécificités client
        </Label>
        <Textarea
          id="clientNeeds"
          value={clientData.needs}
          onChange={(e) => updateField('needs', e.target.value)}
          rows={4}
          placeholder="Décrivez des spécificités du client pour plus de précisions..."
        />
      </div>
    </Card>
  );
}
