import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Copy, CheckCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PromptDisplayProps {
  prompt: string;
}

export function PromptDisplay({ prompt }: PromptDisplayProps) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(prompt);
      setCopied(true);
      toast({
        title: "Prompt copié !",
        description: "Le prompt a été copié dans le presse-papiers.",
      });
      
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      toast({
        title: "Erreur de copie",
        description: "Impossible de copier le prompt dans le presse-papiers.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Generated Prompt */}
      <Card className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Prompt généré automatiquement</h3>
          <Button 
            onClick={copyToClipboard}
            className={`transition-colors ${copied ? 'bg-green-600 hover:bg-green-700' : ''}`}
          >
            {copied ? (
              <>
                <CheckCircle className="w-5 h-5 mr-2" />
                Copié !
              </>
            ) : (
              <>
                <Copy className="w-5 h-5 mr-2" />
                Copier le prompt
              </>
            )}
          </Button>
        </div>
        
        <div className="p-4 bg-gray-50 rounded-lg mb-4">
          <p className="text-sm text-gray-600">
            <strong>Instructions :</strong> Copiez ce prompt, ouvrez soGPT, activez le Deep Reasoning, puis collez-le.
          </p>
        </div>
        
        <div className="p-4 bg-white border border-gray-200 rounded-lg max-h-60 overflow-y-auto">
          <pre className="text-sm text-gray-700 whitespace-pre-wrap">{prompt}</pre>
        </div>
      </Card>

      {/* soGPT Instructions */}
      <Card className="p-6 bg-blue-50 border-blue-200">
        <div className="flex items-start gap-3">
          <Clock className="w-6 h-6 text-blue-600 mt-1" />
          <div>
            <h4 className="font-semibold text-blue-900 mb-2">Instructions pour soGPT</h4>
            <ol className="list-decimal list-inside text-sm text-blue-800 space-y-1">
              <li>Ouvrez soGPT dans un nouvel onglet</li>
              <li>Activez le mode "Deep Reasoning / raisonnement intelligent"</li>
              <li>Collez le prompt généré ci-dessus</li>
              <li>Attendez la réponse complète de l'IA</li>
              <li>Copiez la réponse et collez-la dans la zone ci-dessous</li>
            </ol>
          </div>
        </div>
      </Card>
    </div>
  );
}
