import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, Download } from "lucide-react";
import { extractTableFromText, exportToCSV } from "@/lib/csv-exporter";
import { useToast } from "@/hooks/use-toast";

interface AIResultsProps {
  onResultsChange: (results: string, hasTable: boolean) => void;
  onReset: () => void;
}

export function AIResults({ onResultsChange, onReset }: AIResultsProps) {
  const [results, setResults] = useState('');
  const [hasExtractedTable, setHasExtractedTable] = useState(false);
  const [extractedTable, setExtractedTable] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (results.length > 100) {
      const table = extractTableFromText(results);
      if (table) {
        setExtractedTable(table);
        setHasExtractedTable(true);
        onResultsChange(results, true);
      } else {
        setHasExtractedTable(false);
        onResultsChange(results, false);
      }
    } else {
      setHasExtractedTable(false);
      onResultsChange(results, false);
    }
  }, [results, onResultsChange]);

  const handleDownloadCSV = () => {
    if (!extractedTable) {
      toast({
        title: "Aucun tableau à télécharger",
        description: "Aucun tableau n'a été détecté dans les résultats de l'IA.",
        variant: "destructive",
      });
      return;
    }

    try {
      exportToCSV(extractedTable, 'passporting_analysis');
      toast({
        title: "Téléchargement réussi",
        description: "Le fichier CSV a été téléchargé avec succès.",
      });
    } catch (error) {
      toast({
        title: "Erreur de téléchargement",
        description: error instanceof Error ? error.message : "Erreur inconnue",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* AI Results Input */}
      <Card className="p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">
          Résultat de l'IA - Synthèse et recommandations
        </h3>
        <Textarea
          value={results}
          onChange={(e) => setResults(e.target.value)}
          rows={12}
          placeholder="Collez ici la synthèse finale obtenue par soGPT..."
          className="mb-4"
        />
        
        {hasExtractedTable && (
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <div>
                <h4 className="font-semibold text-green-800">Analyse terminée avec succès !</h4>
                <p className="text-sm text-green-600">
                  Le tableau a été extrait et est prêt pour le téléchargement.
                </p>
              </div>
            </div>
          </div>
        )}
      </Card>

      {/* Action Buttons */}
      <div className="flex justify-center gap-4">
        <Button 
          onClick={handleDownloadCSV}
          disabled={!hasExtractedTable}
          className="bg-green-600 hover:bg-green-700"
        >
          <Download className="w-5 h-5 mr-2" />
          Télécharger le tableau CSV
        </Button>
        <Button variant="outline" onClick={onReset}>
          Recommencer
        </Button>
      </div>

      {/* Completion Banner */}
      {hasExtractedTable && (
        <Card className="p-6 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <div className="text-center">
            <h4 className="text-xl font-bold text-green-800 mb-2">🎉 Processus terminé !</h4>
            <p className="text-green-700">
              Vous avez maintenant une analyse complète générée par IA avec les documents identifiés.
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
