import { Switch } from "@/components/ui/switch";
import { Card } from "@/components/ui/card";
import { ArrowLeftRight } from "lucide-react";

interface DirectionToggleProps {
  direction: 'gp-to-bdd' | 'bdd-to-gp';
  onDirectionChange: (direction: 'gp-to-bdd' | 'bdd-to-gp') => void;
  clientType: string;
}

export function DirectionToggle({ direction, onDirectionChange, clientType }: DirectionToggleProps) {
  const handleToggle = () => {
    const newDirection = direction === 'gp-to-bdd' ? 'bdd-to-gp' : 'gp-to-bdd';
    onDirectionChange(newDirection);
  };

  const getMatrixName = (dir: 'gp-to-bdd' | 'bdd-to-gp') => {
    return dir === 'gp-to-bdd' 
      ? 'Gestion Privée vers Banque de Détail' 
      : 'Banque de Détail vers Gestion Privée';
  };

  const getPersonTypeName = (type: string) => {
    if (!type) return 'Sélectionnez le type de personne ci-dessous';
    return type === 'physique' ? 'Personne Physique' : 'Personne Morale';
  };

  return (
    <Card className="p-6 mb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <ArrowLeftRight className="w-6 h-6 text-primary" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Ordre du Passporting</h3>
            <p className="text-sm text-gray-600">
              Choisissez GP → BDD si le client est en gestion privée; BDD → GP pour l'inverse
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span 
            className={`text-sm font-medium transition-colors duration-200 ${
              direction === 'gp-to-bdd' ? 'text-primary' : 'text-gray-400'
            }`}
          >
            Gestion privée → Banque de détail
          </span>
          <Switch
            checked={direction === 'bdd-to-gp'}
            onCheckedChange={handleToggle}
            className="data-[state=checked]:bg-primary"
          />
          <span 
            className={`text-sm font-medium transition-colors duration-200 ${
              direction === 'bdd-to-gp' ? 'text-primary' : 'text-gray-400'
            }`}
          >
            Banque de détail → Gestion privée
          </span>
        </div>
      </div>
      
      {/* Matrix Information */}
      <div className="mt-4 p-4 bg-gray-50 rounded-lg">
        <div className="text-xs text-gray-600 space-y-1">
          <p>
            <strong>Matrice active :</strong> {getMatrixName(direction)}
          </p>
          <p>
            <strong>Type :</strong> {getPersonTypeName(clientType)}
          </p>
        </div>
      </div>
    </Card>
  );
}
