import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const passportingAnalysis = pgTable("passporting_analysis", {
  id: serial("id").primaryKey(),
  direction: text("direction").notNull(), // 'gp-to-bdd' or 'bdd-to-gp'
  clientType: text("client_type").notNull(), // 'physique' or 'morale'
  clientLab: text("client_lab").notNull(),
  clientCountry: text("client_country"),
  clientPep: text("client_pep").notNull(),
  clientNeeds: text("client_needs"),
  fileContent: text("file_content"),
  generatedPrompt: text("generated_prompt"),
  aiResults: text("ai_results"),
  extractedTable: text("extracted_table"),
});

export const newsletterProcesses = pgTable("newsletter_processes", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  htmlContent: text("html_content"),
  excelContent: text("excel_content"),
  conseillerName: text("conseiller_name"),
  status: text("status").default("created"), // created, processing, completed
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const clientSections = pgTable("client_sections", {
  id: serial("id").primaryKey(),
  processId: integer("process_id").references(() => newsletterProcesses.id).notNull(),
  sectionNumber: integer("section_number").notNull(),
  clientsData: text("clients_data").notNull(), // JSON string
  sectionPrompt: text("section_prompt"),
  aiResponse: text("ai_response"),
});

export const newsletterTitles = pgTable("newsletter_titles", {
  id: serial("id").primaryKey(),
  processId: integer("process_id").references(() => newsletterProcesses.id).notNull(),
  title: text("title").notNull(),
  clientNumbers: text("client_numbers").array(), // Array of client numbers
  comments: text("comments"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertPassportingAnalysisSchema = createInsertSchema(passportingAnalysis).omit({
  id: true,
});

export const insertNewsletterProcessSchema = createInsertSchema(newsletterProcesses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertClientSectionSchema = createInsertSchema(clientSections).omit({
  id: true,
});

export const insertNewsletterTitleSchema = createInsertSchema(newsletterTitles).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertPassportingAnalysis = z.infer<typeof insertPassportingAnalysisSchema>;
export type PassportingAnalysis = typeof passportingAnalysis.$inferSelect;

export type InsertNewsletterProcess = z.infer<typeof insertNewsletterProcessSchema>;
export type NewsletterProcess = typeof newsletterProcesses.$inferSelect;
export type InsertClientSection = z.infer<typeof insertClientSectionSchema>;
export type ClientSection = typeof clientSections.$inferSelect;
export type InsertNewsletterTitle = z.infer<typeof insertNewsletterTitleSchema>;
export type NewsletterTitle = typeof newsletterTitles.$inferSelect;
