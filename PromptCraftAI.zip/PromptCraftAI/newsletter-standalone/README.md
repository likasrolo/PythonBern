# Newsletter Bernstein - Application de Génération de Prompts

Cette application permet de traiter des newsletters HTML et des fichiers Excel de portefeuilles clients pour générer des prompts personnalisés destinés à l'IA.

## Installation

1. **Prérequis**: Node.js (version 18 ou plus récente)

2. **Installation des dépendances**:
```bash
npm install
```

3. **Lancement en mode développement**:
```bash
npm run dev
```

4. **Build pour la production**:
```bash
npm run build
```

## Utilisation

### Étape 1: Upload des fichiers
- **Newsletter HTML**: Sélectionnez votre fichier newsletter au format HTML
- **Portfolio Excel**: Sélectionnez votre fichier de données clients Excel
- **Nom du conseiller**: Saisissez le nom du conseiller

### Étape 2: Génération des prompts
- L'application génère automatiquement 3 prompts personnalisés
- Copiez chaque prompt et collez-le dans votre IA (ChatGPT, Claude, etc.)
- Collez la réponse de l'IA dans la zone de texte correspondante
- Répétez pour les 3 sections

### Étape 3: Newsletter finale
- Cliquez sur "Générer Newsletter Finale" pour télécharger le résultat

## Structure des fichiers

```
newsletter-standalone/
├── src/
│   ├── pages/
│   │   └── Newsletter.jsx    # Composant principal
│   ├── App.jsx              # Application principale
│   ├── main.jsx            # Point d'entrée
│   └── index.css           # Styles CSS
├── package.json            # Dépendances
├── vite.config.js         # Configuration Vite
└── README.md              # Ce fichier
```

## Fonctionnalités

- ✅ Interface drag & drop pour l'upload de fichiers
- ✅ Génération automatique de prompts basés sur les titres de newsletter
- ✅ Copie automatique dans le presse-papier
- ✅ Interface en 2 étapes (Configuration → Génération)
- ✅ Export de la newsletter finale
- ✅ Design responsive avec Tailwind CSS

## Technologies utilisées

- **React 18**: Framework frontend
- **Vite**: Build tool rapide
- **Tailwind CSS**: Framework CSS
- **JavaScript ES6+**: Langage de programmation

## Support

Pour toute question ou problème, contactez l'équipe de développement.